# -*- coding: utf-8 -*-


from dashboard import app

app.run(host="127.0.0.1", port=9090, debug=True)
